package com.hiloxDevelop.EmergenciaAlert;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmergenciaAlertApplicationTests {

	@Test
	void contextLoads() {
	}

}
