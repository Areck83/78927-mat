package com.hiloxDevelop.EmergenciaAlert;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmergenciaAlertApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmergenciaAlertApplication.class, args);
	}

}
