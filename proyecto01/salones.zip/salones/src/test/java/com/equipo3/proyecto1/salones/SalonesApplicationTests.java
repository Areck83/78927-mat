package com.equipo3.proyecto1.salones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalonesApplicationTests {

	@Test
	void contextLoads() {
	}

}
