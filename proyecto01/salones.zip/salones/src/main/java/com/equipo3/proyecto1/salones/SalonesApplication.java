package com.equipo3.proyecto1.salones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalonesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalonesApplication.class, args);
	}

}
